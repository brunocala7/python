arr = []
i = 1
for i in range(0, 1000):
    arr.append(i)

print(len(arr))