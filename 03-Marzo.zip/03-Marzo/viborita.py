import keyboard

mapa = []
vibora = [[1,0],[2,0],[3,0],[4,0]]
cabeza = [0,4]
cola = [0,0]

def mostrarMapa():
    for i in mapa:
        print(i)

def mover(tecla):



for i in range(0,11):
    mapa.append(["_","_","_","_","_","_","_","_","_","_"])

mapa[0][0] = '0'

 

while True:
    tecla = input()

    pos_anterior_x = cabeza

    mostrarMapa()

    if tecla == 'w':
        cabeza[1] -= 1 
    elif tecla == 'a':
        cabeza[0] -= 1
    elif tecla == 's':
        cabeza[1] += 1
    elif tecla == 'd':
        cabeza[0] += 1

    mapa[cabeza[1]][cabeza[0]] = "0"
