set = set()

for i in range(0,3):
    nombre = input("Nombre: ")
    set.add(nombre)

print(set)